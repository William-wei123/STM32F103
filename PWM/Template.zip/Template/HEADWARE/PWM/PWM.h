#ifndef __PWM__H__
#define __PWM__H__
#include "sys.h"

void TIM4_PWM_Init(u16 arr,u16 psc);

#endif
